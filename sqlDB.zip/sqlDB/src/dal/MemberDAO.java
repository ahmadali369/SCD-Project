package dal;

public class MemberDAO {

}
