package dal;

import java.util.HashMap;
import java.util.Map;

public interface IDataFetcher {

	public static  Map<String, Boolean> getAllBooksInSeries(String seriesName){
		Map<String, Boolean> booksInSeries = new HashMap<>();
		return booksInSeries;
		
		
	}
}
