package dal;

public class PeriodiclesDAO {

}
