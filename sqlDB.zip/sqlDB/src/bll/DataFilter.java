package bll;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dal.BookDAO;
import dal.IDataFetcher;

public class DataFilter {
	private IDataFetcher dal;
	MemberDAO mem;
	PeriodiclesDAO per;// which design pattern is used to min. comhvbplexity if interface
	
	public DataFilter(IDataFetcher dal) {
		this.dal=dal;
	}
	///////private DatabaseHandler dal = new DatabaseHandler();
//	private TextFileReader dal = new TextFileReader("C:\\Users\\affan\\eclipse-workspace\\MissingBookFinderLayered\\src\\dal\\book_series_with_books");
	
    public List<String> getMissingBooks(String series) {
        List<String> missingBooks = new ArrayList<>();

        Map<String, Boolean> allBooksInSeries = IDataFetcher.getAllBooksInSeries(series);
        for (Map.Entry<String, Boolean> entry : allBooksInSeries.entrySet()) {
            String book = entry.getKey();
            boolean isMissing = entry.getValue();

            if (isMissing) {
            	missingBooks.add(book);
            }
        }
        return missingBooks;
    }
}
