package bll;

public interface Poem {
    String getTitle();
    void setTitle(String title);
    String getVerse1();
	void setVerse1(String currentVerse1);
	String getVerse2();
	void setVerse2(String currentVerse2);
}
