package bll;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import dal.PoemDAO;

public class PoemBO implements Poem{
	
	private List<Poem> poems;

    // Implement the interface methods here
    @Override
    public String getTitle() {
    	return title;
    }

    @Override
    public void setTitle(String title) {
    	this.title = title;
    }

    private String title;
    private String currentVerse1 = "";
    private String currentVerse2 = "";
    public String getVerse1() {
        return currentVerse1;
    }
    
    @Override
    public void setVerse1(String currentVerse1) {
        this.currentVerse1 =currentVerse1;
    }


    public String getVerse2() {
        return currentVerse2;
    }
    
    @Override
    public void setVerse2(String currentVerse2) {
        this.currentVerse2 =currentVerse2;
    }

    private PoemDAO poemDAO;

    public PoemBO() {
        poemDAO = new PoemDAO();
    }

    public List<Poem> importPoemsFromTextFile(String filepath) {
    	filepath ="E:\\Setups\\Eclipse\\scd_iteration1\\src\\dal\\book_series_with_books.txt";
        List<Poem> poems = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("book_series_with_books.txt"))) {
            String line;
            boolean inPoemSection = false;
            String currentTitle = "";
            String currentVerse1 = "";
            String currentVerse2 = "";

            List<Poem> poems1 = new ArrayList<>();

            while ((line = reader.readLine()) != null) {
                if (line.contains("==========")) {
                    inPoemSection = !inPoemSection;
                    if (!inPoemSection) {
                        if (!currentTitle.isEmpty()) {
                            poems1.add(new PoemDAO(currentTitle, currentVerse1, currentVerse2));
                            currentTitle = "";
                            currentVerse1 = "";
                            currentVerse2 = "";
                        }
                    }
                } else if (inPoemSection) {
                    if (line.startsWith("[")) {
                        currentTitle = line.substring(1, line.indexOf("]")); // Found a poem title
                    } else if (line.startsWith("(")) { // Found a verse
                        String[] parts = line.substring(1, line.length() - 1).split("\\.{3}");
                        if (parts.length >= 1) {
                            currentVerse1 = parts[0];
                        }
                        if (parts.length >= 2) {
                            currentVerse2 = parts[1];
                        }
                    }
                }
            }

            
        } catch (IOException e) {
            e.printStackTrace();
        }

        return poems;
    }

    public boolean savePoemsToDatabase(List<Poem> poems) {
        boolean allSaved = true;
        for (Poem poem : poems) {
            boolean saved = poemDAO.savePoem(poem);
            if (!saved) {
                allSaved = false;
                System.out.println("POEM NOT SAVED");
            }
        }
        return allSaved;
    }
}