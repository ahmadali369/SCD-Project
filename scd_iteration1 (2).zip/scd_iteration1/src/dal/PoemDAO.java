package dal;
import java.sql.*;

import bll.Poem;
public class PoemDAO implements Poem {

	    private Connection connection;
	    private static final String DB_URL = "jdbc:mysql://localhost:3306/missingbookfinder";
	    private static final String DB_USER = "root";
	    private static final String DB_PASSWORD = "";

	    private String title;
	    private String currentVerse1 = "";
	    private String currentVerse2 = "";

	    public PoemDAO(String title, String currentVerse1,String currentVerse2  ) {
	    	this.title = title;
	    	this.currentVerse1=currentVerse1;
	    	this.currentVerse2=currentVerse2;
	        try {
	            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	        } catch (SQLException e) {
	            e.printStackTrace();
	         
	        }
	    }

	    public PoemDAO() {
			// TODO Auto-generated constructor stub
		}

		@Override
	    public String getTitle() {
	        return title;
	    }

	    @Override
	    public void setTitle(String title) {
	        this.title = title;
	    }

	    public String getVerse1() {
	        return currentVerse1;
	    }
	    
	    @Override
	    public void setVerse1(String currentVerse1) {
	        this.currentVerse1 =currentVerse1;
	    }


	    public String getVerse2() {
	        return currentVerse2;
	    }
	    
	    @Override
	    public void setVerse2(String currentVerse2) {
	        this.currentVerse2 =currentVerse2;
	    }

	    public boolean savePoem(Poem poem) {
	    	String sql = "INSERT INTO poems (title, verse1, verse2) VALUES (?, ?, ?)";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	            statement.setString(1, poem.getTitle());
	           // statement.setString(2, poem.getContent());
	            statement.setString(1, poem.getVerse1());
	            statement.setString(1, poem.getVerse2());
	            int rowsInserted = statement.executeUpdate();
	            return rowsInserted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    public Poem getPoem(int poemId) {
	        String sql = "SELECT * FROM poems WHERE id = ?";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	            statement.setInt(1, poemId);
	            ResultSet resultSet = statement.executeQuery();
	            if (resultSet.next()) {
	                String title = resultSet.getString("title");
	                String verse1 = resultSet.getString("verse1");
	                String verse2 = resultSet.getString("verse2");
	                return new PoemDAO(title, verse1, verse2);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }


	    public boolean updatePoem(int poemId, Poem poem) {
	        String sql = "UPDATE poems SET title = ?, verse1 = ?, verse2 = ? WHERE id = ?";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	            statement.setString(1, poem.getTitle());
	            statement.setString(2, poem.getVerse1());
	            statement.setString(3, poem.getVerse2());
	            statement.setInt(4, poemId);
	            int rowsUpdated = statement.executeUpdate();
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	           
	            return false;
	        }
	    }

	}


